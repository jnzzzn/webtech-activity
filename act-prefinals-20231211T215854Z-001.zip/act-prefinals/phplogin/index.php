<!DOCTYPE html>
<html lang="en">
<head>

    <title>Form</title>
</head>
<body>

<div id="form">
    <h1>HELLO</h1>
    <form name="form" method="POST">
        <label >Username: </label>
        <input type="text" name="user" id="user">
        <label >Password: </label>
        <input type="password" name="user" id="user">
    </form>
</div>
    
</body>
</html>